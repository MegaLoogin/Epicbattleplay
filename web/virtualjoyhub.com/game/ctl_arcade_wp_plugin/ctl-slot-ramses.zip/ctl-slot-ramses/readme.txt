=== CTL Slot Ramses ===
Tags: bonus, bonus game, casino, egypt, gambling, html5 slot machine, instant win, money, poker, slot, slot machine, sweepstakes, videopoker, win
Requires at least: 4.3
Tested up to: 4.3

Add Slot Ramses to CTL Arcade plugin

== Description ==
Add Slot Ramses to CTL Arcade plugin


	